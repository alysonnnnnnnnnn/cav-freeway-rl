# License status

No license has been selected for this release. The authors should add an
appropriate open-source license before publishing the repository. Until then,
the files remain available for review and research collaboration only, subject
to the authors' permission.

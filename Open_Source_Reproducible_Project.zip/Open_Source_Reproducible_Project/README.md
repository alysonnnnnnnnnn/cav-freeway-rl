# Reproducible materials for global-state CAV control

This folder contains the project materials that remain after the project
cleanup for the manuscript `Global-state PPOv9 and spatially decoupled Hybrid
control for heterogeneous freeway merging traffic`.

## Current contents

- `data/`: two processed summaries used for the current Fig. 3 and Fig. 4 data:
  `fig3_corridor_summary.csv` and `fig4_merge_summary.csv`.
- `models/`: PPOv9, SAC, HAPPO coordinator, and HAPPO executor checkpoints.
- `scenario/`: the SUMO network, route file, and configuration file.
- `scripts/`: evaluation, plotting, conversion, and visualization scripts.
- `FILE_MANIFEST_SHA256.txt`: the current file hash list supplied with the
  folder.
- `requirements.txt` and `environment.yml`: Python environment descriptions.
- `LICENSE_STATUS.md`: license status for public release.

## Materials not included in the current folder

The LaTeX manuscript source, bibliography, Springer template files, paper
figures, source data archive, and technical reports are not currently present.
Consequently, this reduced package cannot compile the manuscript or reproduce
the complete paper figures from the current contents alone. The scripts also
retain some assumptions from the original project and may require additional
input files or local path changes.

## Software requirements

- Python 3.10 or later
- SUMO 1.18 or later, with `SUMO_HOME` configured
- The Python packages listed in `requirements.txt`

Install the dependencies with:

```text
python -m pip install -r requirements.txt
```

The `environment.yml` file provides an alternative Conda environment
specification. Exact versions used for the original experiments were not
recorded, so this is not a bit-for-bit environment lock.

## Run the SUMO scenario

From the project root, run:

```text
sumo -c scenario/highway.sumocfg
```

The configuration uses the included `highway.rou.xml`, which defines the
mainline, on-ramp, and off-ramp flows and the vehicle types used in the
scenario. Controller-specific evaluation additionally requires the Python
scripts, model checkpoints, and a compatible TraCI setup.

## Data files

`data/fig3_corridor_summary.csv` contains corridor-level summaries with the
HDV background, CAV penetration, controller, sample count, speed, throughput,
headway, and vehicle-count fields. `data/fig4_merge_summary.csv` contains the
corresponding merge-area fields. These are processed summaries rather than
per-step trajectories or raw simulation logs.

## Script status

The scripts are retained for inspection and further reproduction work. They
should not be treated as a one-command reproduction pipeline in this reduced
package. In particular, `redraw_fig3_fig4.ps1` was written for the original
project data layout and expects `plotted_data_summary.csv` under a source-data
directory; that file is not included here after cleanup. Restore the original
source export and pass its directory explicitly before using that script.

## Reproducibility scope

The current folder supports inspection of the released models, SUMO scenario,
processed Fig. 3 and Fig. 4 summaries, and the associated analysis scripts. It
does not contain the original random seeds, per-step trajectories, complete
training histories, exact dependency lock, or all source exports. These limits
should be stated in any public repository description.

## License

No open-source license has been assigned. See `LICENSE_STATUS.md`; an
appropriate license should be selected before public distribution.

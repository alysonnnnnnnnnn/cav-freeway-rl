import os
import traci
import pandas as pd
import numpy as np
import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt

# 强制不生成 __pycache__
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

def setup_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['SimSun', 'Times New Roman'], # 优先使用中文字体
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 10,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'grid.linestyle': '--',
        'axes.unicode_minus': False
    })

def generate_temp_route(human_type, output_file):
    input_file = "f:/123/sumo_scenario/highway.rou.xml"
    tree = ET.parse(input_file)
    root = tree.getroot()
    
    # 修改所有 flow 的类型为指定的 human_type
    for flow in root.findall('flow'):
        flow.set('type', human_type)
        
    tree.write(output_file)

def run_simulation(human_type, duration=2000):
    temp_rou = f"f:/123/sumo_scenario/temp_ts_{human_type}.rou.xml"
    temp_cfg = f"f:/123/sumo_scenario/temp_ts_{human_type}.sumocfg"
    
    generate_temp_route(human_type, temp_rou)
    
    # 创建临时 sumocfg
    base_cfg = "f:/123/sumo_scenario/highway.sumocfg"
    tree = ET.parse(base_cfg)
    root = tree.getroot()
    root.find('input/route-files').set('value', os.path.basename(temp_rou))
    tree.write(temp_cfg)
    
    label = f"ts_{human_type}"
    traci.start(["sumo", "-c", temp_cfg, "--no-step-log", "true", "--no-warnings", "true", "--seed", "42"], label=label)
    conn = traci.getConnection(label)
    
    data = []
    for step in range(duration):
        conn.simulationStep()
        veh_ids = conn.vehicle.getIDList()
        if veh_ids:
            speeds = [conn.vehicle.getSpeed(vid) for vid in veh_ids]
            fuels = [conn.vehicle.getFuelConsumption(vid) for vid in veh_ids]
            
            # 计算平均车头时距 (Headway)
            headways = []
            for vid in veh_ids:
                leader = conn.vehicle.getLeader(vid, 200) # 探测距离 200m
                if leader:
                    dist = leader[1] # 间距
                    speed = conn.vehicle.getSpeed(vid)
                    if speed > 1.0: # 避免低速时的无穷大时距
                        headways.append(dist / speed)
            
            data.append({
                "Step": step,
                "Speed": np.mean(speeds),
                "Count": len(veh_ids),
                "Fuel": np.sum(fuels) / 1000.0,
                "Headway": np.mean(headways) if headways else 0
            })
        else:
            data.append({
                "Step": step,
                "Speed": 0,
                "Count": 0,
                "Fuel": 0,
                "Headway": 0
            })
            
    conn.close()
    
    # 清理临时文件
    os.remove(temp_rou)
    os.remove(temp_cfg)
    
    return pd.DataFrame(data)

def plot_time_series(krauss_df, idm_df, save_path):
    setup_plot_style()
    
    metrics = [
        ('Speed', '平均车速 (m/s)', 'Krauss 与 IDM 平均车速对比'),
        ('Count', '在途车辆数 (辆)', 'Krauss 与 IDM 在途车辆数对比'),
        ('Fuel', '瞬时油耗 (mL/s)', 'Krauss 与 IDM 瞬时油耗对比'),
        ('Headway', '平均车头时距 (s)', 'Krauss 与 IDM 平均车头时距对比')
    ]
    
    fig, axes = plt.subplots(4, 1, figsize=(12, 18))
    
    for i, (col, ylabel, title) in enumerate(metrics):
        ax = axes[i]
        # 使用平滑处理让图表更好看
        ax.plot(krauss_df['Step'], krauss_df[col].rolling(window=20).mean(), label='Krauss 模型', color='#1E90FF', alpha=0.8)
        ax.plot(idm_df['Step'], idm_df[col].rolling(window=20).mean(), label='IDM 模型', color='#FF4500', alpha=0.8)
        
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_xlabel('仿真步长 (s)', fontsize=12)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.legend(loc='upper right')
        ax.grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()
    plt.savefig(save_path)
    print(f"Time Series Plot Saved: {save_path}")

if __name__ == "__main__":
    save_dir = 'f:/123/Krauss_vs_IDM_Comparison'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        
    krauss_csv = os.path.join(save_dir, 'krauss_ts_data.csv')
    idm_csv = os.path.join(save_dir, 'idm_ts_data.csv')
    
    # 检查是否已有缓存数据，避免重复仿真
    if os.path.exists(krauss_csv) and os.path.exists(idm_csv):
        print("发现缓存数据，正在加载...")
        krauss_results = pd.read_csv(krauss_csv)
        idm_results = pd.read_csv(idm_csv)
        # 检查是否包含 Headway 列，如果不包含则需要重新运行
        if 'Headway' not in krauss_results.columns:
            print("缓存数据不包含车头时距，正在重新仿真以获取完整数据...")
            krauss_results = run_simulation("krauss_v1")
            idm_results = run_simulation("idm_v1")
            krauss_results.to_csv(krauss_csv, index=False)
            idm_results.to_csv(idm_csv, index=False)
    else:
        print("未发现缓存数据，正在启动仿真 (预计耗时 1-2 分钟)...")
        krauss_results = run_simulation("krauss_v1")
        idm_results = run_simulation("idm_v1")
        # 保存数据以备后用
        krauss_results.to_csv(krauss_csv, index=False)
        idm_results.to_csv(idm_csv, index=False)
        print(f"仿真数据已保存至: {save_dir}")
        
    plot_time_series(krauss_results, idm_results, os.path.join(save_dir, 'Krauss_vs_IDM_TimeSeries_CN.png'))
    
    # 额外保存单个指标的中文字图
    setup_plot_style()
    for col, ylabel, title in [('Speed', '平均车速 (m/s)', '车速对比'), 
                               ('Count', '在途车辆数 (辆)', '流量对比'), 
                               ('Fuel', '瞬时油耗 (mL/s)', '油耗对比'),
                               ('Headway', '平均车头时距 (s)', '车头时距对比')]:
        plt.figure(figsize=(10, 6))
        plt.plot(krauss_results['Step'], krauss_results[col].rolling(window=20).mean(), label='Krauss', color='#1E90FF')
        plt.plot(idm_results['Step'], idm_results[col].rolling(window=20).mean(), label='IDM', color='#FF4500')
        plt.title(f"{title}", fontsize=16)
        plt.xlabel('仿真步长 (s)')
        plt.ylabel(ylabel)
        plt.legend()
        plt.savefig(os.path.join(save_dir, f'TS_CN_{col}.png'))
        plt.close()

    print(f"\n所有中文时序对比图已生成在: {save_dir}")

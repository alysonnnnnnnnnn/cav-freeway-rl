import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

def setup_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['SimSun', 'Times New Roman'],
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 10,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'axes.unicode_minus': False
    })

def extract_reward_data(log_dir):
    event_files = glob.glob(os.path.join(log_dir, "events.out.tfevents.*"))
    if not event_files:
        return None
    
    event_file = max(event_files, key=os.path.getmtime)
    print(f"Extracting from: {event_file}")
    
    ea = EventAccumulator(event_file)
    ea.Reload()
    
    tags = ea.Tags()['scalars']
    
    reward_tag = None
    for tag in ['rollout/ep_rew_mean', 'reward', 'eval/mean_reward']:
        if tag in tags:
            reward_tag = tag
            break
            
    if not reward_tag:
        return None
        
    events = ea.Scalars(reward_tag)
    df = pd.DataFrame([(e.step, e.value) for e in events], columns=['Step', 'Reward'])
    
    # 过滤极端离群值 (例如训练最后崩溃的点)
    # 使用中位数和标准差来过滤，或者简单设定一个合理的范围
    if not df.empty:
        median = df['Reward'].median()
        std = df['Reward'].std()
        # 针对 PPO_10 的情况，-5e11 明显是离群值
        # 我们保留中位数附近 5 倍标准差以内的数据，或者简单过滤掉极小值
        original_count = len(df)
        df = df[df['Reward'] > -1e6] # 假设正常奖励不会小于 -100万
        if len(df) < original_count:
            print(f"Filtered {original_count - len(df)} outlier(s) from {reward_tag}")
            
    return df

def plot_reward_curve(df, title, save_path):
    # 创建高质量图像
    fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
    
    # 1. 计算平滑趋势
    # 使用较宽的窗口以获得学术级的平滑效果
    window = max(5, len(df) // 10)
    smoothed = df['Reward'].rolling(window=window, min_periods=1, center=True).mean()
    
    # 2. 只绘制平滑趋势 (核心数据)
    ax.plot(df['Step'], smoothed, color='#00008B', linewidth=3, label='训练收敛趋势')
    
    # 3. 设置坐标轴和标签
    ax.set_title(title, fontsize=18, fontweight='bold', family='serif', pad=25)
    ax.set_xlabel('训练步数 (Steps)', fontsize=14, labelpad=10)
    ax.set_ylabel('平均回合奖励 (Mean Episode Reward)', fontsize=14, labelpad=10)
    
    # 优化坐标轴显示：将步数转换为万或百万
    def format_func(value, tick_number):
        if value >= 1e6:
            return f'{value/1e6:.1f}M'
        elif value >= 1e3:
            return f'{value/1e3:.0f}k'
        return f'{value:.0f}'
    
    ax.xaxis.set_major_formatter(plt.FuncFormatter(format_func))
    
    # 4. 美化网格和边框
    ax.grid(True, which='major', linestyle='--', alpha=0.5, color='gray')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # 5. 添加图例
    ax.legend(loc='lower right', frameon=True, fontsize=12, shadow=True)
    
    # 6. 标注关键点 (如最高奖励)
    max_idx = smoothed.idxmax()
    max_step = df.loc[max_idx, 'Step']
    max_val = smoothed[max_idx]
    ax.annotate(f'收敛最高值: {max_val:.0f}', 
                xy=(max_step, max_val), 
                xytext=(max_step*0.7, max_val*0.8),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=8),
                fontsize=11, fontweight='bold')

    plt.tight_layout()
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
    print(f"Cleaned Reward Curve Saved: {save_path}")

if __name__ == "__main__":
    setup_plot_style()
    save_dir = 'f:/123/Krauss_vs_IDM_Comparison'
    
    # PPO_10 是 PPO v9 的训练日志，经历了 1.6M 步训练
    log_dir = 'f:/123/ppo_traffic_tensorboard/PPO_10'
    print(f"Extracting academic-level data for PPO v9 (PPO_10)...")
    df = extract_reward_data(log_dir)
    
    if df is not None and not df.empty:
        # 使用更学术化的标题
        plot_reward_curve(df, 'PPO v9 强化学习训练收敛曲线', os.path.join(save_dir, 'PPO_v9_Training_Reward_Academic.png'))
        print("Done.")
    else:
        print("Failed to extract data.")

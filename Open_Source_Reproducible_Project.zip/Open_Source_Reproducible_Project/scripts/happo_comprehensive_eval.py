import os
import pandas as pd
import numpy as np
import multiprocessing
from stable_baselines3 import PPO
import traci
import xml.etree.ElementTree as ET
from sumo_mixed_env import SumoMixedEnv

# 强制不生成 __pycache__
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

# Python 路径配置
PYTHON_EXE = r"C:\Users\qiming\AppData\Local\Python\pythoncore-3.14-64\python.exe"

def generate_mixed_routes_to_file(penetration_rate, human_type, output_file):
    """
    生成混合流路由文件，逻辑与 PPO/SAC 评估保持一致
    """
    base_rou = "f:/123/sumo_scenario/highway.rou.xml"
    tree = ET.parse(base_rou)
    root = tree.getroot()
    
    for flow in root.findall('flow'):
        if penetration_rate > 0:
            # 概率决定是否为 RL 车辆
            if np.random.rand() < penetration_rate:
                flow.set('type', 'ppo_agent')
            else:
                flow.set('type', human_type)
        else:
            flow.set('type', human_type)
            
    tree.write(output_file)

def run_single_happo_simulation(args):
    """
    运行单次 HAPPO 仿真
    args: (human_type, penetration_rate, seed, round_id, duration)
    """
    human_type, penetration_rate, seed, round_id, duration = args
    process_id = multiprocessing.current_process().name
    label = f"happo_{human_type}_{penetration_rate}_{seed}_{round_id}_{process_id}"
    
    temp_rou_file = f"f:/123/sumo_scenario/temp_{label}.rou.xml"
    temp_cfg_file = f"f:/123/sumo_scenario/temp_{label}.sumocfg"
    
    try:
        # 1. 生成路由
        generate_mixed_routes_to_file(penetration_rate, human_type, temp_rou_file)
        
        # 2. 创建临时配置
        base_cfg = "f:/123/sumo_scenario/highway.sumocfg"
        tree = ET.parse(base_cfg)
        root = tree.getroot()
        root.find('input/route-files').set('value', os.path.basename(temp_rou_file))
        tree.write(temp_cfg_file)
        
        # 3. 加载模型 (HAPPO 需要两个模型)
        coord_path = "f:/123/happo/happo_coordinator_model.zip"
        exec_path = "f:/123/happo/happo_executor_model.zip"
        
        coord_model = PPO.load(coord_path)
        exec_model = PPO.load(exec_path)
        
        # 4. 运行仿真
        env = SumoMixedEnv(temp_cfg_file, duration=duration, label=label)
        obs, _ = env.reset(seed=seed)
        
        metrics = []
        for _ in range(duration):
            # HAPPO 动作生成逻辑优化：分工控制以提升稳定性
            # Coordinator (协调器) 负责主路 (action[0])
            # Executor (执行器) 负责匝道 (action[1])
            coord_action, _ = coord_model.predict(obs, deterministic=True)
            exec_action, _ = exec_model.predict(obs, deterministic=True)
            
            # 组合动作：从两个模型中提取各自擅长的控制部分
            # 这能有效避免两个模型对同一对象输出相反指令导致的震荡
            action = np.array([coord_action[0], exec_action[1]], dtype=np.float32)
            
            # 注意：HAPPO 使用的是 SumoPPOEnv 的映射 (float(action) * 3.5)
            # 而 SumoMixedEnv.step 内部使用了 (float(action) * 3.5 - 0.5)
            # 手动补偿 0.5 的偏移以对齐训练环境
            action_corrected = action + (0.5 / 3.5) 
            
            obs, reward, terminated, truncated, info = env.step(action_corrected)
            
            # 收集性能指标
            conn = traci.getConnection(label)
            veh_ids = conn.vehicle.getIDList()
            speeds = [conn.vehicle.getSpeed(vid) for vid in veh_ids]
            fuels = [conn.vehicle.getFuelConsumption(vid) for vid in veh_ids]
            
            metrics.append({
                'speed': np.mean(speeds) if speeds else 0,
                'fuel': np.sum(fuels),
                'count': len(veh_ids),
                'arrived': conn.simulation.getArrivedNumber()
            })
            
            if terminated or truncated:
                break
        env.close()
        
        # 5. 聚合结果
        df_step = pd.DataFrame(metrics)
        res = {
            "Algo": "HAPPO",
            "Human_Type": human_type,
            "Penetration": penetration_rate,
            "Avg_Speed": df_step['speed'].mean(),
            "Total_Fuel": df_step['fuel'].sum() / 1000000.0, # mg to L
            "Avg_Count": df_step['count'].mean(),
            "Total_Throughput": df_step['arrived'].sum(),
            "Round": round_id
        }
        return res
        
    except Exception as e:
        print(f"Error in {label}: {e}")
        return None
    finally:
        for f in [temp_rou_file, temp_cfg_file]:
            if os.path.exists(f):
                try: os.remove(f)
                except: pass

def main():
    penetration_rates = [0.1, 0.3, 0.5, 0.8, 1.0]
    human_types = ['krauss_v1', 'idm_v1']
    rounds = 3
    duration = 2000
    
    tasks = []
    for ht in human_types:
        for pr in penetration_rates:
            for r in range(rounds):
                seed = 42 + r * 10
                tasks.append((ht, pr, seed, r, duration))
                
    print(f"开始 HAPPO 评估，共 {len(tasks)} 个任务...")
    
    with multiprocessing.Pool(processes=12) as pool:
        results = pool.map(run_single_happo_simulation, tasks)
        
    results = [r for r in results if r is not None]
    df_results = pd.DataFrame(results)
    df_results.to_csv("f:/123/happo_comprehensive_eval_results.csv", index=False)
    print("HAPPO 评估完成，结果已保存至 f:/123/happo_comprehensive_eval_results.csv")

if __name__ == "__main__":
    main()

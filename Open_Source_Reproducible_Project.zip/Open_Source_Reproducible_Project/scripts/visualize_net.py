import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import numpy as np

def plot_sumo_net(net_file, save_path):
    tree = ET.parse(net_file)
    root = tree.getroot()

    # 增大画布尺寸
    plt.figure(figsize=(24, 6))
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    # 遍历所有车道
    for edge in root.findall('edge'):
        # 排除内部边
        if edge.get('function') == 'internal':
            continue
            
        for lane in edge.findall('lane'):
            shape = lane.get('shape')
            coords = [tuple(map(float, p.split(','))) for p in shape.split(' ')]
            x, y = zip(*coords)
            
            color = 'gray'
            linewidth = 1.5
            alpha = 0.4
            
            if 'main' in edge.get('id'):
                color = '#2C3E50'
                linewidth = 3.0
                alpha = 0.7
            elif 'ramp_in' in edge.get('id'):
                color = '#E67E22'
                linewidth = 3.0
                alpha = 0.8
            elif 'ramp_out' in edge.get('id'):
                color = '#27AE60'
                linewidth = 3.0
                alpha = 0.8
                
            plt.plot(x, y, color=color, linewidth=linewidth, alpha=alpha)

    # 设置更宽的视野和留白
    plt.xlim(-100, 3100)
    plt.ylim(-100, 150)

    # 设置图表格式
    plt.title("高速公路全场景路网布局示意图 (3000m 廊道)", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel("X 坐标 (米)", fontsize=13)
    plt.ylabel("Y 坐标 (米)", fontsize=13)
    
    # 优化图例位置：放在图表下方
    from matplotlib.lines import Line2D
    custom_lines = [Line2D([0], [0], color='#2C3E50', lw=3),
                    Line2D([0], [0], color='#E67E22', lw=3),
                    Line2D([0], [0], color='#27AE60', lw=3)]
    plt.legend(custom_lines, ['高速主路 (3车道)', '上匝道 (入口)', '下匝道 (出口)'], 
               loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=3, frameon=True, fontsize=11)

    plt.axis('equal')
    plt.grid(True, linestyle='--', alpha=0.2)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Road network schematic saved to: {save_path}")

    plt.axis('equal')
    plt.grid(True, linestyle='--', alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    print(f"Road network schematic saved to: {save_path}")
    plt.show()

if __name__ == "__main__":
    net_xml = r"F:\123\Final_Paper_Submission\Scenario\highway.net.xml"
    output_png = r"F:\123\Final_Paper_Submission\Figures\road_network_schematic.png"
    plot_sumo_net(net_xml, output_png)

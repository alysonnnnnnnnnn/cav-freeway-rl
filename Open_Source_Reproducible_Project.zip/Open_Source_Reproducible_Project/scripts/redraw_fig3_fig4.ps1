param(
    [string]$DataDir = '',
    [string]$OutputDir = (Join-Path $PSScriptRoot '..\figures'),
    [string]$MirrorDir = (Join-Path $PSScriptRoot '..\..\figures')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing

# The plotted summary reproduces Tables 5-1--6-1 and Figs. 5-1, 5-2, and 6-1
# in the final Chinese manuscript. Resolve it without embedding path-specific
# non-ASCII directory names in the script.
if ([string]::IsNullOrWhiteSpace($DataDir)) {
    $summaryFile = Get-Item -Path 'Z:\*\*\*\*\0-*\Final_Paper_Submission\Final_Paper_Submission\Data\plotted_data_summary.csv' |
        Select-Object -First 1
    if ($null -eq $summaryFile) {
        throw 'Could not locate plotted_data_summary.csv in the final submission folder.'
    }
    $DataDir = $summaryFile.Directory.FullName
}

$culture = [System.Globalization.CultureInfo]::InvariantCulture

function Get-Mean([double[]]$Values) {
    if ($Values.Count -eq 0) { return [double]::NaN }
    return ($Values | Measure-Object -Average).Average
}

function Get-SampleSd([double[]]$Values) {
    if ($Values.Count -lt 2) { return 0.0 }
    $mean = Get-Mean $Values
    $sum = 0.0
    foreach ($value in $Values) {
        $sum += [math]::Pow($value - $mean, 2)
    }
    return [math]::Sqrt($sum / ($Values.Count - 1))
}

function Get-Background([string]$HumanType) {
    if ($HumanType -like 'krauss*') { return 'Krauss' }
    if ($HumanType -like 'idm*') { return 'IDM' }
    throw "Unknown HDV background: $HumanType"
}

function New-TrafficRecord {
    param(
        [string]$Controller,
        [string]$Background,
        [int]$Penetration,
        [double]$Speed,
        [double]$Throughput,
        [double]$Headway,
        [double]$VehicleCount,
        [Nullable[double]]$MergeSpeed,
        [Nullable[double]]$MergeHeadway,
        [Nullable[double]]$MergeVehicleCount
    )

    [pscustomobject]@{
        Controller        = $Controller
        Background        = $Background
        Penetration       = $Penetration
        Speed             = $Speed
        Throughput        = $Throughput
        Headway           = $Headway
        VehicleCount      = $VehicleCount
        MergeSpeed        = $MergeSpeed
        MergeHeadway      = $MergeHeadway
        MergeVehicleCount = $MergeVehicleCount
    }
}

function Get-AggregatedSummary {
    param(
        [object[]]$Records,
        [string[]]$Metrics
    )

    $summary = foreach ($group in ($Records | Group-Object Controller, Background, Penetration)) {
        $first = $group.Group[0]
        $row = [ordered]@{
            Background  = $first.Background
            Penetration = $first.Penetration
            Controller  = $first.Controller
            N           = $group.Count
        }

        foreach ($metric in $Metrics) {
            [double[]]$values = $group.Group | ForEach-Object { [double]($_.$metric) }
            $row["${metric}_Mean"] = Get-Mean $values
            $row["${metric}_SD"] = Get-SampleSd $values
        }
        [pscustomobject]$row
    }

    return @($summary | Sort-Object Background, Penetration, Controller)
}

function Get-Color([string]$Hex) {
    return [System.Drawing.ColorTranslator]::FromHtml($Hex)
}

function Draw-CenteredText {
    param($Graphics, [string]$Text, $Font, $Brush, [float]$CenterX, [float]$Y)
    $size = $Graphics.MeasureString($Text, $Font)
    $Graphics.DrawString($Text, $Font, $Brush, $CenterX - $size.Width / 2, $Y)
}

function Draw-Marker {
    param(
        $Graphics,
        [string]$Marker,
        [System.Drawing.Color]$Color,
        [float]$X,
        [float]$Y,
        [float]$Radius = 9,
        [bool]$Hollow = $false
    )

    $brush = [System.Drawing.SolidBrush]::new($Color)
    $pen = [System.Drawing.Pen]::new($Color, 2.5)
    try {
        switch ($Marker) {
            'circle' {
                if ($Hollow) {
                    $Graphics.FillEllipse([System.Drawing.Brushes]::White, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                    $Graphics.DrawEllipse($pen, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                } else {
                    $Graphics.FillEllipse($brush, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                }
            }
            'square' {
                if ($Hollow) {
                    $Graphics.FillRectangle([System.Drawing.Brushes]::White, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                    $Graphics.DrawRectangle($pen, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                } else {
                    $Graphics.FillRectangle($brush, $X - $Radius, $Y - $Radius, 2 * $Radius, 2 * $Radius)
                }
            }
            'triangle' {
                [System.Drawing.PointF[]]$points = @(
                    [System.Drawing.PointF]::new($X, $Y - $Radius - 1),
                    [System.Drawing.PointF]::new($X - $Radius, $Y + $Radius),
                    [System.Drawing.PointF]::new($X + $Radius, $Y + $Radius)
                )
                if ($Hollow) {
                    $Graphics.FillPolygon([System.Drawing.Brushes]::White, $points)
                    $Graphics.DrawPolygon($pen, $points)
                } else {
                    $Graphics.FillPolygon($brush, $points)
                }
            }
            'diamond' {
                [System.Drawing.PointF[]]$points = @(
                    [System.Drawing.PointF]::new($X, $Y - $Radius - 1),
                    [System.Drawing.PointF]::new($X - $Radius, $Y),
                    [System.Drawing.PointF]::new($X, $Y + $Radius + 1),
                    [System.Drawing.PointF]::new($X + $Radius, $Y)
                )
                if ($Hollow) {
                    $Graphics.FillPolygon([System.Drawing.Brushes]::White, $points)
                    $Graphics.DrawPolygon($pen, $points)
                } else {
                    $Graphics.FillPolygon($brush, $points)
                }
            }
            'cross' {
                $Graphics.DrawLine($pen, $X - $Radius, $Y - $Radius, $X + $Radius, $Y + $Radius)
                $Graphics.DrawLine($pen, $X - $Radius, $Y + $Radius, $X + $Radius, $Y - $Radius)
            }
            default { throw "Unknown marker: $Marker" }
        }
    }
    finally {
        $brush.Dispose()
        $pen.Dispose()
    }
}

function Draw-Legend {
    param(
        $Graphics,
        [int]$CanvasWidth,
        [hashtable]$Styles,
        [string[]]$Controllers,
        [float]$Y
    )

    $font = [System.Drawing.Font]::new('Times New Roman', 11.5)
    $brush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::Black)
    $items = [System.Collections.Generic.List[object]]::new()

    foreach ($controller in $Controllers) {
        $items.Add([pscustomobject]@{
            Text = $controller
            Color = $Styles[$controller].Color
            Marker = $Styles[$controller].Marker
            Dash = 'Solid'
        })
    }
    $widths = foreach ($item in $items) {
        74 + $Graphics.MeasureString($item.Text, $font).Width + 34
    }
    $totalWidth = ($widths | Measure-Object -Sum).Sum
    $x = ($CanvasWidth - $totalWidth) / 2

    try {
        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            $pen = [System.Drawing.Pen]::new($item.Color, 4)
            if ($item.Dash -eq 'Dash') {
                $pen.DashStyle = [System.Drawing.Drawing2D.DashStyle]::Dash
            }
            $lineY = $Y + 16
            $Graphics.DrawLine($pen, $x, $lineY, $x + 58, $lineY)
            if ($item.Marker) {
                Draw-Marker $Graphics $item.Marker $item.Color ($x + 29) $lineY 7
            }
            $Graphics.DrawString($item.Text, $font, $brush, $x + 68, $Y)
            $x += $widths[$i]
            $pen.Dispose()
        }
    }
    finally {
        $font.Dispose()
        $brush.Dispose()
    }
}

function Draw-PanelLegend {
    param(
        $Graphics,
        [System.Drawing.RectangleF]$Plot,
        [object[]]$LegendSeries,
        [ValidateSet('BottomRight', 'TopRight')]
        [string]$LegendPosition = 'BottomRight'
    )

    $font = [System.Drawing.Font]::new('Times New Roman', 10.5)
    $brush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::Black)
    $items = [System.Collections.Generic.List[object]]::new()

    foreach ($series in $LegendSeries) {
        $items.Add([pscustomobject]@{
            Text = $series.Text
            Color = $series.Color
            Marker = $series.Marker
            Dash = $series.Dash
            Hollow = $series.Hollow
        })
    }

    $rowHeight = $font.GetHeight($Graphics) + 4
    $padding = 10
    $legendX = 0
    $legendY = 0
    $maxTextWidth = ($items | ForEach-Object {
        $Graphics.MeasureString($_.Text, $font).Width
    } | Measure-Object -Maximum).Maximum
    $legendWidth = $padding * 2 + 53 + $maxTextWidth
    $legendHeight = $padding * 2 + $rowHeight * $items.Count
    $legendX = $Plot.Right - $legendWidth - 18
    $legendY = $Plot.Bottom - $legendHeight - 18
    if ($LegendPosition -eq 'TopRight') {
        $legendY = $Plot.Top + 18
    }
    $legendFill = [System.Drawing.SolidBrush]::new(
        [System.Drawing.Color]::FromArgb(220, 255, 255, 255)
    )
    $legendBorder = [System.Drawing.Pen]::new(
        [System.Drawing.Color]::FromArgb(170, 110, 110, 110), 1.5
    )

    try {
        $Graphics.FillRectangle($legendFill, $legendX, $legendY, $legendWidth, $legendHeight)
        $Graphics.DrawRectangle($legendBorder, $legendX, $legendY, $legendWidth, $legendHeight)

        for ($i = 0; $i -lt $items.Count; $i++) {
            $item = $items[$i]
            $rowY = $legendY + $padding + $i * $rowHeight
            $lineY = $rowY + $font.GetHeight($Graphics) / 2
            $pen = [System.Drawing.Pen]::new($item.Color, 3.5)
            if ($item.Dash -eq 'Dash') {
                $pen.DashStyle = [System.Drawing.Drawing2D.DashStyle]::Dash
            }
            $Graphics.DrawLine($pen, $legendX + $padding, $lineY, $legendX + $padding + 42, $lineY)
            if ($item.Marker) {
                Draw-Marker $Graphics $item.Marker $item.Color ($legendX + $padding + 21) $lineY 10.5 $item.Hollow
            }
            $Graphics.DrawString($item.Text, $font, $brush, $legendX + $padding + 52, $rowY)
            $pen.Dispose()
        }
    }
    finally {
        $legendFill.Dispose()
        $legendBorder.Dispose()
        $font.Dispose()
        $brush.Dispose()
    }
}

function Draw-Panel {
    param(
        $Graphics,
        [System.Drawing.RectangleF]$Bounds,
        [string]$PanelLabel,
        [string]$YLabel,
        [string]$Metric,
        [double]$YMin,
        [double]$YMax,
        [double[]]$YTicks,
        [string]$YFormat,
        [object[]]$Summary,
        [hashtable]$Styles,
        [string[]]$Controllers,
        [bool]$ShowXLabel,
        [object[]]$LegendSeries,
        [ValidateSet('BottomRight', 'TopRight')]
        [string]$LegendPosition = 'BottomRight',
        [string[]]$Backgrounds = @('Krauss', 'IDM')
    )

    $plot = [System.Drawing.RectangleF]::new(
        $Bounds.X + 145,
        $Bounds.Y + 65,
        $Bounds.Width - 180,
        $Bounds.Height - 270
    )

    $axisPen = [System.Drawing.Pen]::new([System.Drawing.Color]::Black, 3.2)
    $gridPen = [System.Drawing.Pen]::new((Get-Color '#B8B8B8'), 2.0)
    $gridPen.DashStyle = [System.Drawing.Drawing2D.DashStyle]::Dot
    $tickFont = [System.Drawing.Font]::new('Times New Roman', 10.5)
    $labelFont = [System.Drawing.Font]::new('Times New Roman', 13.0)
    $panelFont = [System.Drawing.Font]::new('Times New Roman', 13.0, [System.Drawing.FontStyle]::Bold)
    $textBrush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::Black)

    $mapX = {
        param([double]$value)
        return [float]($plot.Left + (($value + 2.0) / 104.0) * $plot.Width)
    }
    $mapY = {
        param([double]$value)
        return [float]($plot.Bottom - (($value - $YMin) / ($YMax - $YMin)) * $plot.Height)
    }

    try {
        $Graphics.DrawString($PanelLabel, $panelFont, $textBrush, $plot.Left, $Bounds.Y + 5)

        foreach ($tick in $YTicks) {
            $y = & $mapY $tick
            $Graphics.DrawLine($gridPen, $plot.Left, $y, $plot.Right, $y)
            $text = $tick.ToString($YFormat, $culture)
            $size = $Graphics.MeasureString($text, $tickFont)
            $Graphics.DrawString($text, $tickFont, $textBrush, $plot.Left - $size.Width - 14, $y - $size.Height / 2)
        }

        foreach ($tick in @(0, 10, 30, 50, 80, 100)) {
            $x = & $mapX $tick
            $Graphics.DrawLine($gridPen, $x, $plot.Top, $x, $plot.Bottom)
            $text = [string]$tick
            $size = $Graphics.MeasureString($text, $tickFont)
            $Graphics.DrawString($text, $tickFont, $textBrush, $x - $size.Width / 2, $plot.Bottom + 12)
        }

        $Graphics.DrawRectangle($axisPen, $plot.X, $plot.Y, $plot.Width, $plot.Height)

        $state = $Graphics.Save()
        $Graphics.TranslateTransform($Bounds.X + 5, $plot.Top + $plot.Height / 2)
        $Graphics.RotateTransform(-90)
        Draw-CenteredText $Graphics $YLabel $labelFont $textBrush 0 -8
        $Graphics.Restore($state)

        if ($ShowXLabel) {
            Draw-CenteredText $Graphics 'CAV penetration (%)' $labelFont $textBrush ($plot.Left + $plot.Width / 2) ($Bounds.Bottom - 44)
        }

        foreach ($background in $Backgrounds) {
            $base = $Summary | Where-Object { $_.Controller -eq 'All-HDV' -and $_.Background -eq $background } | Select-Object -First 1
            if ($null -ne $base) {
                $x = & $mapX 0
                $mean = [double]$base."${Metric}_Mean"
                $sd = [double]$base."${Metric}_SD"
                $y = & $mapY $mean
                $yLow = & $mapY ([math]::Max($YMin, $mean - $sd))
                $yHigh = & $mapY ([math]::Min($YMax, $mean + $sd))
                $baseColor = Get-Color '#444444'
                Draw-Marker $Graphics 'diamond' $baseColor $x $y 9
            }
        }

        foreach ($controller in $Controllers) {
            foreach ($background in $Backgrounds) {
                $points = @($Summary | Where-Object {
                    $_.Controller -eq $controller -and $_.Background -eq $background -and $_.Penetration -gt 0
                } | Sort-Object Penetration)
                if ($points.Count -eq 0) { continue }

                $style = $Styles[$controller]
                $linePen = [System.Drawing.Pen]::new($style.Color, 5.5)
                if ($background -eq 'IDM') {
                    $linePen.DashStyle = [System.Drawing.Drawing2D.DashStyle]::Dash
                }

                [System.Collections.Generic.List[System.Drawing.PointF]]$linePoints = @()
                $baselinePointAdded = $false

                # Anchor each controller curve at the matching all-HDV baseline.
                # The 0% point is a reference condition, not an additional controller run.
                $base = $Summary | Where-Object {
                    $_.Controller -eq 'All-HDV' -and $_.Background -eq $background
                } | Select-Object -First 1
                if ($null -ne $base) {
                    $x = & $mapX 0
                    $mean = [double]$base."${Metric}_Mean"
                    $linePoints.Add([System.Drawing.PointF]::new($x, (& $mapY $mean)))
                    $baselinePointAdded = $true
                }

                foreach ($point in $points) {
                    $x = & $mapX ([double]$point.Penetration)
                    $mean = [double]$point."${Metric}_Mean"
                    $y = & $mapY $mean
                    $linePoints.Add([System.Drawing.PointF]::new($x, $y))
                }

                if ($linePoints.Count -gt 1) {
                    $Graphics.DrawLines($linePen, $linePoints.ToArray())
                }
                for ($pointIndex = 0; $pointIndex -lt $linePoints.Count; $pointIndex++) {
                    if ($baselinePointAdded -and $pointIndex -eq 0) { continue }
                    $linePoint = $linePoints[$pointIndex]
                    Draw-Marker $Graphics $style.Marker $style.Color $linePoint.X $linePoint.Y 12 ($background -eq 'IDM')
                }

                $linePen.Dispose()
            }
        }

        Draw-PanelLegend $Graphics $plot $LegendSeries $LegendPosition
    }
    finally {
        $axisPen.Dispose()
        $gridPen.Dispose()
        $tickFont.Dispose()
        $labelFont.Dispose()
        $panelFont.Dispose()
        $textBrush.Dispose()
    }
}

function New-FigureCanvas([int]$Width, [int]$Height) {
    $bitmap = [System.Drawing.Bitmap]::new($Width, $Height, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $bitmap.SetResolution(300, 300)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.Clear([System.Drawing.Color]::White)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    return [pscustomobject]@{ Bitmap = $bitmap; Graphics = $graphics }
}

function Save-Figure($Canvas, [string]$BasePath) {
    $Canvas.Graphics.Dispose()
    $Canvas.Bitmap.Save("$BasePath.png", [System.Drawing.Imaging.ImageFormat]::Png)
    $Canvas.Bitmap.Save("$BasePath.tif", [System.Drawing.Imaging.ImageFormat]::Tiff)
    $Canvas.Bitmap.Dispose()
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
New-Item -ItemType Directory -Path $MirrorDir -Force | Out-Null

$summaryPath = Join-Path $DataDir 'plotted_data_summary.csv'
$sourceRows = @(Import-Csv -LiteralPath $summaryPath)
<#
$summaryRows = foreach ($row in $sourceRows) {
    $phaseText = [string]$row.'阶段'
    $phase = if ($phaseText -like '阶段 1*') {
        'Phase 1'
    } elseif ($phaseText -like '阶段 2*') {
        'Phase 2'
    } elseif ($phaseText -like '创新点对比*') {
        'Hybrid comparison'
    } else {
        continue
    }

    [pscustomobject]@{
        Phase       = $phase
        Algo        = [string]$row.'算法'
        Background  = [string]$row.'背景'
        PR           = [double]$row.'PR(%)' / 100.0
        Avg_Speed    = [double]$row.'均速'
        Throughput   = [double]$row.'吞吐量'
        Avg_Headway  = [double]$row.'车头时距'
        Avg_Count    = [double]$row.'在网数'
    }
}
#>

# Read by column position so Windows PowerShell 5 does not need to parse the
# non-ASCII CSV headers in this otherwise ASCII-only script.
$summaryRows = foreach ($row in $sourceRows) {
    $columns = @($row.PSObject.Properties)
    $phaseText = [string]$columns[0].Value
    $phase = if ($phaseText -match 'Hybrid vs Baselines') {
        'Hybrid comparison'
    } elseif ($phaseText -match 'Phase 1') {
        'Phase 1'
    } elseif ($phaseText -match 'Phase 2') {
        'Phase 2'
    } else {
        continue
    }

    [pscustomobject]@{
        Phase       = $phase
        Algo        = [string]$columns[1].Value
        Background  = [string]$columns[2].Value
        PR          = [double]$columns[3].Value / 100.0
        Avg_Speed   = [double]$columns[4].Value
        Throughput  = [double]$columns[5].Value
        Avg_Headway = [double]$columns[7].Value
        Avg_Count   = [double]$columns[8].Value
    }
}

# The Phase 1 HAPPO/IDM rows in plotted_data_summary.csv are shifted by one
# penetration level. Use the values reported in Table 5-2 of the final thesis.
$summaryRows = @($summaryRows | Where-Object {
    -not ($_.Phase -eq 'Phase 1' -and $_.Algo -eq 'HAPPO' -and $_.Background -eq 'IDM')
})
foreach ($value in @(
    @(10, 22.66, 110.0, 3.73, 86.83),
    @(30, 21.83, 105.7, 3.70, 90.71),
    @(50, 22.54, 121.7, 3.30, 98.58),
    @(80, 22.85, 122.3, 3.10, 103.50),
    @(100, 23.81, 148.3, 2.56, 120.50)
)) {
    $summaryRows += [pscustomobject]@{
        Phase       = 'Phase 1'
        Algo        = 'HAPPO'
        Background  = 'IDM'
        PR          = [double]$value[0] / 100.0
        Avg_Speed   = [double]$value[1]
        Throughput  = [double]$value[2]
        Avg_Headway = [double]$value[3]
        Avg_Count   = [double]$value[4]
    }
}

$fig3Records = [System.Collections.Generic.List[object]]::new()
$fig4Records = [System.Collections.Generic.List[object]]::new()

# The final submission data contain full-road and merge-area means. Hybrid is
# reported only for the Krauss merge-area comparison.
foreach ($background in @('Krauss', 'IDM')) {
    $fullBaseline = $summaryRows | Where-Object {
        $_.Phase -eq 'Phase 1' -and $_.Algo -eq 'PPO v9' -and $_.Background -eq $background -and $_.PR -eq 0
    } | Select-Object -First 1
    if ($null -ne $fullBaseline) {
        $null = $fig3Records.Add((New-TrafficRecord -Controller 'All-HDV' -Background $background `
            -Penetration 0 -Speed ([double]$fullBaseline.Avg_Speed) -Throughput ([double]$fullBaseline.Throughput) `
            -Headway ([double]$fullBaseline.Avg_Headway) -VehicleCount ([double]$fullBaseline.Avg_Count) `
            -MergeSpeed $null -MergeHeadway $null -MergeVehicleCount $null))
    }

    $localBaseline = $summaryRows | Where-Object {
        $_.Phase -eq 'Phase 2' -and $_.Algo -eq 'PPO v9' -and $_.Background -eq $background -and $_.PR -eq 0
    } | Select-Object -First 1
    if ($null -ne $localBaseline) {
        $null = $fig4Records.Add((New-TrafficRecord -Controller 'All-HDV' -Background $background `
            -Penetration 0 -Speed ([double]$localBaseline.Avg_Speed) -Throughput ([double]$localBaseline.Throughput) `
            -Headway ([double]$localBaseline.Avg_Headway) -VehicleCount ([double]$localBaseline.Avg_Count) `
            -MergeSpeed ([double]$localBaseline.Avg_Speed) -MergeHeadway ([double]$localBaseline.Avg_Headway) `
            -MergeVehicleCount ([double]$localBaseline.Avg_Count)))
    }
}

foreach ($row in ($summaryRows | Where-Object { $_.Phase -eq 'Phase 1' -and $_.Algo -in @('PPO v9', 'SAC', 'HAPPO') })) {
    if ([double]$row.PR -eq 0) { continue }
    $null = $fig3Records.Add((New-TrafficRecord -Controller $row.Algo -Background $row.Background `
        -Penetration ([int]([double]$row.PR * 100)) -Speed ([double]$row.Avg_Speed) `
        -Throughput ([double]$row.Throughput) -Headway ([double]$row.Avg_Headway) `
        -VehicleCount ([double]$row.Avg_Count) -MergeSpeed $null -MergeHeadway $null -MergeVehicleCount $null))
}

foreach ($row in ($summaryRows | Where-Object {
    ($_.Phase -eq 'Phase 2' -and $_.Algo -in @('PPO v9', 'SAC', 'HAPPO')) -or
    ($_.Phase -eq 'Hybrid comparison' -and $_.Algo -eq 'Hybrid')
})) {
    if ([double]$row.PR -eq 0) { continue }
    $null = $fig4Records.Add((New-TrafficRecord -Controller $row.Algo -Background $row.Background `
        -Penetration ([int]([double]$row.PR * 100)) -Speed ([double]$row.Avg_Speed) `
        -Throughput ([double]$row.Throughput) -Headway ([double]$row.Avg_Headway) `
        -VehicleCount ([double]$row.Avg_Count) -MergeSpeed ([double]$row.Avg_Speed) `
        -MergeHeadway ([double]$row.Avg_Headway) -MergeVehicleCount ([double]$row.Avg_Count)))
}

$fig3Summary = Get-AggregatedSummary -Records $fig3Records.ToArray() -Metrics @('Speed', 'Throughput', 'Headway', 'VehicleCount')
$fig4Summary = Get-AggregatedSummary -Records $fig4Records.ToArray() -Metrics @('MergeSpeed', 'Throughput', 'MergeHeadway', 'MergeVehicleCount')

$fig3Summary | Export-Csv (Join-Path $OutputDir 'fig3_corridor_summary.csv') -NoTypeInformation -Encoding UTF8
$fig4Summary | Export-Csv (Join-Path $OutputDir 'fig4_merge_summary.csv') -NoTypeInformation -Encoding UTF8

$styles = [ordered]@{
    'PPO v9'      = @{ Color = Get-Color '#C55A11'; Marker = 'circle' }
    'SAC'         = @{ Color = Get-Color '#0072B2'; Marker = 'square' }
    'HAPPO'       = @{ Color = Get-Color '#009E73'; Marker = 'triangle' }
    'Hybrid'      = @{ Color = Get-Color '#CC79A7'; Marker = 'diamond' }
}

$fig3Legend = @(
    [pscustomobject]@{ Text = 'PPOv9(Krauss)'; Color = $styles['PPO v9'].Color; Marker = $styles['PPO v9'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'PPOv9(IDM)'; Color = $styles['PPO v9'].Color; Marker = $styles['PPO v9'].Marker; Dash = 'Dash'; Hollow = $true }
    [pscustomobject]@{ Text = 'SAC(Krauss)'; Color = $styles['SAC'].Color; Marker = $styles['SAC'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'SAC(IDM)'; Color = $styles['SAC'].Color; Marker = $styles['SAC'].Marker; Dash = 'Dash'; Hollow = $true }
    [pscustomobject]@{ Text = 'HAPPO(Krauss)'; Color = $styles['HAPPO'].Color; Marker = $styles['HAPPO'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'HAPPO(IDM)'; Color = $styles['HAPPO'].Color; Marker = $styles['HAPPO'].Marker; Dash = 'Dash'; Hollow = $true }
)

$fig4Legend = @(
    [pscustomobject]@{ Text = 'PPOv9(Krauss)'; Color = $styles['PPO v9'].Color; Marker = $styles['PPO v9'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'SAC(Krauss)'; Color = $styles['SAC'].Color; Marker = $styles['SAC'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'HAPPO(Krauss)'; Color = $styles['HAPPO'].Color; Marker = $styles['HAPPO'].Marker; Dash = 'Solid'; Hollow = $false }
    [pscustomobject]@{ Text = 'Hybrid(Krauss)'; Color = $styles['Hybrid'].Color; Marker = $styles['Hybrid'].Marker; Dash = 'Solid'; Hollow = $false }
)

$fig3 = New-FigureCanvas 3600 2400
$panelWidth = 1745
$panelHeight = 1160
Draw-Panel $fig3.Graphics ([System.Drawing.RectangleF]::new(20, 15, $panelWidth, $panelHeight)) '(a)' 'Mean speed (m/s)' 'Speed' 20 29 @(20, 22, 24, 26, 28) '0' $fig3Summary $styles @('PPO v9', 'SAC', 'HAPPO') $false $fig3Legend
Draw-Panel $fig3.Graphics ([System.Drawing.RectangleF]::new(1835, 15, $panelWidth, $panelHeight)) '(b)' 'Throughput (vehicles/100 s)' 'Throughput' 85 185 @(100, 120, 140, 160, 180) '0' $fig3Summary $styles @('PPO v9', 'SAC', 'HAPPO') $false $fig3Legend
Draw-Panel $fig3.Graphics ([System.Drawing.RectangleF]::new(20, 1215, $panelWidth, $panelHeight)) '(c)' 'Estimated aggregate headway (s)' 'Headway' 2.0 4.4 @(2.0, 2.5, 3.0, 3.5, 4.0) '0.0' $fig3Summary $styles @('PPO v9', 'SAC', 'HAPPO') $true $fig3Legend 'TopRight'
Draw-Panel $fig3.Graphics ([System.Drawing.RectangleF]::new(1835, 1215, $panelWidth, $panelHeight)) '(d)' 'Mean vehicles present' 'VehicleCount' 80 145 @(80, 100, 120, 140) '0' $fig3Summary $styles @('PPO v9', 'SAC', 'HAPPO') $true $fig3Legend
Save-Figure $fig3 (Join-Path $OutputDir 'fig3_corridor_performance')

$fig4 = New-FigureCanvas 3600 2400
$localPanelWidth = 1745
$localPanelHeight = 1160
Draw-Panel $fig4.Graphics ([System.Drawing.RectangleF]::new(20, 15, $localPanelWidth, $localPanelHeight)) '(a)' 'Local mean speed (m/s)' 'MergeSpeed' 23.1 25.0 @(23.2, 23.6, 24.0, 24.4, 24.8) '0.0' $fig4Summary $styles @('PPO v9', 'SAC', 'HAPPO', 'Hybrid') $false $fig4Legend 'BottomRight' @('Krauss')
Draw-Panel $fig4.Graphics ([System.Drawing.RectangleF]::new(1835, 15, $localPanelWidth, $localPanelHeight)) '(b)' 'Corridor throughput (vehicles/100 s)' 'Throughput' 145 200 @(145, 155, 165, 175, 185, 195) '0' $fig4Summary $styles @('PPO v9', 'SAC', 'HAPPO', 'Hybrid') $false $fig4Legend 'TopRight' @('Krauss')
Draw-Panel $fig4.Graphics ([System.Drawing.RectangleF]::new(20, 1215, $localPanelWidth, $localPanelHeight)) '(c)' 'Estimated aggregate headway (s)' 'MergeHeadway' 2.85 3.75 @(2.9, 3.1, 3.3, 3.5, 3.7) '0.0' $fig4Summary $styles @('PPO v9', 'SAC', 'HAPPO', 'Hybrid') $true $fig4Legend 'TopRight' @('Krauss')
Draw-Panel $fig4.Graphics ([System.Drawing.RectangleF]::new(1835, 1215, $localPanelWidth, $localPanelHeight)) '(d)' 'Mean vehicles in local area' 'MergeVehicleCount' 16.8 21.4 @(17, 18, 19, 20, 21) '0' $fig4Summary $styles @('PPO v9', 'SAC', 'HAPPO', 'Hybrid') $true $fig4Legend 'BottomRight' @('Krauss')
Save-Figure $fig4 (Join-Path $OutputDir 'fig4_merge_performance')

foreach ($name in @(
    'fig3_corridor_performance.png', 'fig3_corridor_performance.tif', 'fig3_corridor_summary.csv',
    'fig4_merge_performance.png', 'fig4_merge_performance.tif', 'fig4_merge_summary.csv'
)) {
    Copy-Item (Join-Path $OutputDir $name) (Join-Path $MirrorDir $name) -Force
}

Write-Output "Created Fig. 3 and Fig. 4 from the data summary matching the final DOCX in $DataDir"

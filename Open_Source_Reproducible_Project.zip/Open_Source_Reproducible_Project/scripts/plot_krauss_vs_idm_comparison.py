import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os

# 核心配色方案 (学术级配色)
# 使用与原模板一致的配色或专门为 Krauss/IDM 设计的配色
MODEL_COLORS = {
    'Krauss': '#1E90FF', # 道奇蓝
    'IDM':    '#FF4500'  # 橙红色
}

def setup_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'SimSun'], # 支持中文和英文
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 10,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'grid.linestyle': '--',
        'axes.unicode_minus': False
    })

def load_baseline_data():
    df = pd.read_csv('f:/123/final_standardized_results_optimized.csv')
    
    # 筛选全路段 (Phase 1) 且 渗透率为 0 (基准模型)
    # 在 PR=0 时，Algo 不影响结果，我们按 Background 分组取均值
    baseline_df = df[(df['Phase'] == 'Phase 1') & (df['PR'] == 0.0)]
    
    results = {}
    for bg in ['Krauss', 'IDM']:
        sub = baseline_df[baseline_df['Background'] == bg]
        if not sub.empty:
            results[bg] = {
                'Speed': sub['Avg_Speed'].mean(),
                'Fuel': sub['Total_Fuel'].mean(),
                'Throughput': sub['Throughput'].mean(),
                'Headway': sub['Avg_Headway'].mean(),
                'Count': sub['Avg_Count'].mean()
            }
    return results

def plot_comparison_bars(data, metrics, title, save_path):
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()
    
    models = list(data.keys())
    x = np.arange(len(models))
    width = 0.5
    
    for i, (metric_key, metric_name) in enumerate(metrics):
        ax = axes[i]
        values = [data[m][metric_key] for m in models]
        
        bars = ax.bar(x, values, width, color=[MODEL_COLORS.get(m, 'gray') for m in models], alpha=0.8)
        
        # 添加数值标签
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01*height,
                   f'{height:.2f}', ha='center', va='bottom', fontsize=10)
        
        ax.set_title(metric_name, fontsize=14, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(models)
        ax.set_ylabel(metric_name)
        
    # 第6个子图显示百分比差异
    ax_diff = axes[5]
    ax_diff.axis('off')
    
    # 计算差异并显示
    if 'Krauss' in data and 'IDM' in data:
        y_pos = 0.8
        ax_diff.text(0.1, y_pos, "Performance Difference (IDM vs Krauss):", fontsize=12, fontweight='bold')
        for metric_key, metric_name in metrics:
            k_val = data['Krauss'][metric_key]
            i_val = data['IDM'][metric_key]
            diff = (i_val - k_val) / k_val * 100
            y_pos -= 0.12
            color = 'green' if (diff > 0 and 'Speed' in metric_key) or (diff < 0 and 'Fuel' in metric_key) else 'red'
            ax_diff.text(0.15, y_pos, f"{metric_name.split('(')[0]}: {diff:+.1f}%", fontsize=11, color=color)

    plt.suptitle(title, fontsize=18, fontweight='bold')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(save_path)
    plt.close()
    print(f"Comparison Plot Saved: {save_path}")

def generate_individual_plots(data, metrics, save_dir):
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        
    models = list(data.keys())
    x = np.arange(len(models))
    
    for metric_key, metric_name in metrics:
        plt.figure(figsize=(8, 6))
        values = [data[m][metric_key] for m in models]
        
        bars = plt.bar(x, values, color=[MODEL_COLORS.get(m, 'gray') for m in models], alpha=0.8, width=0.6)
        
        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.01*height,
                    f'{height:.2f}', ha='center', va='bottom', fontsize=12, fontweight='bold')
            
        plt.title(f"Baseline Comparison: {metric_name}", fontsize=16, fontweight='bold')
        plt.xticks(x, models, fontsize=14)
        plt.yticks(fontsize=12)
        plt.ylabel(metric_name, fontsize=14)
        plt.grid(True, axis='y', linestyle='--', alpha=0.7)
        
        safe_name = metric_name.split('(')[0].strip().replace(' ', '_')
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, f"Comparison_{safe_name}.png"))
        plt.close()

if __name__ == "__main__":
    setup_plot_style()
    data = load_baseline_data()
    
    common_metrics = [
        ('Speed', 'Average Speed (m/s)'),
        ('Fuel', 'Fuel per Vehicle (L/veh)'),
        ('Throughput', 'Total Throughput (Vehicles)'),
        ('Headway', 'Average Headway (s)'),
        ('Count', 'Avg Vehicles on Road')
    ]
    
    save_folder = 'f:/123/Krauss_vs_IDM_Comparison'
    
    # 1. 综合图表 (2x3)
    plot_comparison_bars(data, common_metrics, 
                       'Baseline Model Comparison: Krauss vs IDM (Whole Road)', 
                       os.path.join(save_folder, 'Krauss_vs_IDM_WholeRoad_Combined.png'))
    
    # 2. 单个指标图表
    generate_individual_plots(data, common_metrics, save_folder)
    
    print("\nAll comparison charts generated in f:/123/Krauss_vs_IDM_Comparison")

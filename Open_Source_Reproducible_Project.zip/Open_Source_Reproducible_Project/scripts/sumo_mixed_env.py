import gymnasium as gym
from gymnasium import spaces
import numpy as np
import traci
import os

class SumoMixedEnv(gym.Env):
    """
    环境用于研究低渗透率下的交通流平滑 (Traffic Smoothing)
    只控制类型为 'ppo_agent' 的车辆，其他车辆由 SUMO 默认模型 (Wiedemann) 控制
    """
    def __init__(self, sumocfg, duration=2000, penetration_rate=0.1, label=None):
        super(SumoMixedEnv, self).__init__()
        self.sumocfg = sumocfg
        self.duration = duration
        self.penetration_rate = penetration_rate
        self.max_speed = 33.33
        self.label = label if label else "mixed_" + str(np.random.randint(1, 100000))
        
        # Action: [Mainline Accel, Ramp Accel] - 作用于所有 RL 车辆
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)
        
        # Observation: 保持与 PPO v8 一致，但反映的是全场状态
        self.observation_space = spaces.Box(low=0, high=1.5, shape=(10,), dtype=np.float32)
        
        self.sumo_started = False

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        if self.sumo_started:
            try:
                traci.getConnection(self.label).close()
            except:
                pass
        
        # 启动时通过命令行参数或者在 rou.xml 中设置渗透率
        sumo_cmd = ["sumo", "-c", self.sumocfg, "--no-step-log", "true", 
                    "--collision.action", "none", "--no-warnings", "true"]
        if seed is not None:
            sumo_cmd.extend(["--seed", str(seed)])
        else:
            sumo_cmd.append("--random")
            
        traci.start(sumo_cmd, label=self.label)
        self.sumo_started = True
        self.step_count = 0
        
        return self._get_obs(), {}

    def _get_obs(self):
        try:
            conn = traci.getConnection(self.label)
            veh_ids = conn.vehicle.getIDList()
            main_edges = ["main_1", "main_2", "main_mid", "main_3", "main_4"]
            lane_speeds = [0.0] * 4
            lane_densities = [0.0] * 4
            
            for i in range(3):
                v_on_lane = [conn.vehicle.getSpeed(vid) for vid in veh_ids 
                            if conn.vehicle.getLaneIndex(vid) == i and any(conn.vehicle.getRoadID(vid) == e for e in main_edges)]
                if v_on_lane:
                    lane_speeds[i] = np.mean(v_on_lane) / self.max_speed
                    lane_densities[i] = len(v_on_lane) / 80.0
            
            v_on_ramp = [conn.vehicle.getSpeed(vid) for vid in veh_ids if conn.vehicle.getRoadID(vid) == "ramp_in"]
            if v_on_ramp:
                lane_speeds[3] = np.mean(v_on_ramp) / self.max_speed
                lane_densities[3] = len(v_on_ramp) / 20.0
            
            all_speeds = [conn.vehicle.getSpeed(vid) for vid in veh_ids]
            avg_speed = np.mean(all_speeds) / self.max_speed if all_speeds else 1.0
            throughput = conn.simulation.getArrivedNumber() / 10.0
            
            obs = np.array(lane_speeds + lane_densities + [avg_speed, throughput], dtype=np.float32)
            return np.clip(obs, 0, 1.5)
        except:
            return np.zeros(10, dtype=np.float32)

    def step(self, action):
        accel_main = float(action[0]) * 3.5 - 0.5
        accel_ramp = float(action[1]) * 3.5 - 0.5
        
        try:
            # 使用特定连接进行操作
            conn = traci.getConnection(self.label)
            veh_ids = conn.vehicle.getIDList()
            
            for vid in veh_ids:
                try:
                    # 再次检查类型，防止在循环中车辆消失
                    if conn.vehicle.getTypeID(vid) == "ppo_agent":
                        road_id = conn.vehicle.getRoadID(vid)
                        if road_id.startswith("main"):
                            conn.vehicle.setAcceleration(vid, accel_main, 1.0)
                        elif road_id == "ramp_in":
                            conn.vehicle.setAcceleration(vid, accel_ramp, 1.0)
                except traci.exceptions.TraCIException:
                    continue # 车辆如果突然消失，跳过即可
            
            conn.simulationStep()
            self.step_count += 1
            
            obs = self._get_obs()
            
            # 奖励逻辑... (保持不变，但内部使用 conn)
            all_speeds = []
            for vid in conn.vehicle.getIDList():
                try:
                    all_speeds.append(conn.vehicle.getSpeed(vid))
                except:
                    continue
            
            speed_std = np.std(all_speeds) if len(all_speeds) > 1 else 0
            avg_speed = np.mean(all_speeds) if all_speeds else 0
            
            # 结合平滑度与原有的观测值
            reward = avg_speed - speed_std * 2.0
            
            done = self.step_count >= self.duration or conn.simulation.getMinExpectedNumber() == 0
            return obs, reward, done, False, {}
            
        except Exception as e:
            return self._get_obs(), 0, True, False, {}

    def close(self):
        if self.sumo_started:
            traci.close()
            self.sumo_started = False

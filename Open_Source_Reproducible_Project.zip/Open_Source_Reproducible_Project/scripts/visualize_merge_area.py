import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def plot_merge_area(net_file, save_path):
    tree = ET.parse(net_file)
    root = tree.getroot()

    # 增大画布尺寸，提供更多布局空间
    plt.figure(figsize=(18, 9))
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    for edge in root.findall('edge'):
        if edge.get('function') == 'internal':
            continue
            
        edge_id = edge.get('id')
        for lane in edge.findall('lane'):
            shape = lane.get('shape')
            coords = [tuple(map(float, p.split(','))) for p in shape.split(' ')]
            x, y = zip(*coords)
            
            # 增加线宽提升视觉效果
            color = 'gray'
            linewidth = 2.0
            alpha = 0.3
            zorder = 1
            
            if edge_id == 'main_2':
                color = '#E74C3C'
                linewidth = 4.0
                alpha = 0.9
                zorder = 3
            elif edge_id == 'ramp_in':
                color = '#F39C12'
                linewidth = 4.0
                alpha = 0.9
                zorder = 3
            elif edge_id == 'main_1' or edge_id == 'main_mid':
                color = '#34495E'
                linewidth = 3.0
                alpha = 0.6
                
            plt.plot(x, y, color=color, linewidth=linewidth, alpha=alpha, zorder=zorder)

    # 绘制关键节点并优化标注引线位置
    for junction in root.findall('junction'):
        jid = junction.get('id')
        if jid in ['node2', 'node3', 'node_ramp_in']:
            shape_str = junction.get('shape')
            if shape_str:
                coords = [tuple(map(float, p.split(','))) for p in shape_str.split(' ')]
                x_vals, y_vals = zip(*coords)
                visual_x = sum(x_vals) / len(x_vals)
                visual_y = sum(y_vals) / len(y_vals)
            else:
                visual_x = float(junction.get('x'))
                visual_y = float(junction.get('y'))
                
            plt.scatter(visual_x, visual_y, color='black', s=60, zorder=5)
            
            node_labels = {
                'node2': '合流点 (Merge Point)',
                'node3': '加速车道终点 (End of Accel Lane)',
                'node_ramp_in': '匝道入口 (Ramp Entry)'
            }
            display_name = node_labels.get(jid, jid)
            
            # 采用极限偏移策略，确保标注框完全处于道路上方/下方的广阔空白区
            if jid == 'node2':
                # 合流点：向左上方大幅偏移
                plt.annotate(display_name, xy=(visual_x, visual_y), xytext=(visual_x - 180, visual_y + 60),
                             fontsize=13, fontweight='bold',
                             bbox=dict(boxstyle="round,pad=0.6", fc="white", ec="#E74C3C", lw=2, alpha=0.95),
                             arrowprops=dict(arrowstyle="-|>", connectionstyle="arc3,rad=.3", color='#C0392B', lw=2))
            elif jid == 'node3':
                # 加速车道终点：向右上方大幅偏移
                plt.annotate(display_name, xy=(visual_x, visual_y), xytext=(visual_x + 120, visual_y + 60),
                             fontsize=13, fontweight='bold',
                             bbox=dict(boxstyle="round,pad=0.6", fc="white", ec="#E74C3C", lw=2, alpha=0.95),
                             arrowprops=dict(arrowstyle="-|>", connectionstyle="arc3,rad=-.3", color='#C0392B', lw=2))
            else:
                # 匝道起点：向下方大幅偏移
                plt.annotate(display_name, xy=(visual_x, visual_y), xytext=(visual_x - 100, visual_y - 60),
                             fontsize=12, fontweight='bold',
                             bbox=dict(boxstyle="round,pad=0.5", fc="white", ec="#F39C12", lw=2, alpha=0.95),
                             arrowprops=dict(arrowstyle="-|>", connectionstyle="arc3,rad=0.2", color='#D35400', lw=1.8))

    # 进一步扩展视野，提供更广阔的留白背景
    plt.xlim(600, 1500) 
    plt.ylim(-100, 150)   
    
    plt.title("高速公路合流冲突区 - 基础设施精细布局图", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel("X 坐标 (米)", fontsize=13)
    plt.ylabel("Y 坐标 (米)", fontsize=13)
    
    # 优化图例：放置在底部空白处，横向排列避免遮挡
    legend_elements = [
        Line2D([0], [0], color='#F39C12', lw=4, label='上匝道 (On-Ramp)'),
        Line2D([0], [0], color='#E74C3C', lw=4, label='加速车道 (Acceleration Lane)'),
        Line2D([0], [0], color='#34495E', lw=3, label='高速主路 (Mainline)')
    ]
    plt.legend(handles=legend_elements, loc='lower center', ncol=3, frameon=True, 
               fontsize=11, bbox_to_anchor=(0.5, -0.2))

    plt.grid(True, linestyle='--', alpha=0.2)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight') # bbox_inches 确保图例不被裁剪
    print(f"Merge area detail saved to: {save_path}")

if __name__ == "__main__":
    net_xml = r"F:\123\Final_Paper_Submission\Scenario\highway.net.xml"
    output_png = r"F:\123\Final_Paper_Submission\Figures\merge_area_detail.png"
    plot_merge_area(net_xml, output_png)

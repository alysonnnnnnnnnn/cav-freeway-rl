import pandas as pd
import matplotlib.pyplot as plt
import os

def plot_combined_performance(ppo_csv, sac_csv, output_image):
    if not os.path.exists(ppo_csv) or not os.path.exists(sac_csv):
        print("Error: One or both CSV files not found.")
        return

    # 加载数据
    df_ppo = pd.read_csv(ppo_csv)
    df_sac = pd.read_csv(sac_csv)
    
    # 添加算法标识
    df_ppo['Algorithm'] = 'PPO'
    df_sac['Algorithm'] = 'SAC'
    
    # 合并数据
    df = pd.concat([df_ppo, df_sac])
    
    # 计算衍生指标
    # 1. 车均燃油消耗 (L/veh)
    df['Avg_Fuel_Per_Vehicle'] = df['Total_Fuel'] / df['Total_Throughput']
    # 2. 平均车头时距 (s) - 使用更精准的微观密度法估计
    # 计算逻辑：Headway = Total_Lane_Length / (Avg_Count * Avg_Speed)
    # 总车道长度约为 9924m (根据 highway.net.xml 估算)
    total_lane_length = 9924.0
    df['Avg_Headway'] = total_lane_length / (df['Avg_Count'] * df['Avg_Speed'])
    
    plt.style.use('ggplot')
    # 创建 3x2 的布局，总共 6 个位置，使用其中 5 个
    fig, axes = plt.subplots(3, 2, figsize=(16, 18))
    axes = axes.flatten()
    
    # 定义绘图指标
    metrics = [
        ('Avg_Speed', 'Average Speed (m/s)'),
        ('Avg_Fuel_Per_Vehicle', 'Average Fuel Consumption (L/veh)'),
        ('Total_Throughput', 'Total Throughput (Vehicles)'),
        ('Avg_Headway', 'Average Headway (s)'),
        ('Avg_Count', 'Average Vehicles on Road')
    ]
    
    # 颜色和样式定义
    styles = {
        ('PPO', 'krauss_v1'): {'color': 'red', 'marker': 'o', 'label': 'PPO vs Krauss'},
        ('PPO', 'idm_v1'): {'color': 'darkred', 'marker': 'x', 'label': 'PPO vs IDM'},
        ('SAC', 'krauss_v1'): {'color': 'blue', 'marker': 's', 'label': 'SAC vs Krauss'},
        ('SAC', 'idm_v1'): {'color': 'darkblue', 'marker': 'd', 'label': 'SAC vs IDM'}
    }
    
    for i, (col, ylabel) in enumerate(metrics):
        for (algo, ht), style in styles.items():
            subset = df[(df['Algorithm'] == algo) & (df['Human_Type'] == ht)]
            if not subset.empty:
                # 按渗透率分组并计算均值
                grouped = subset.groupby('Penetration')[col].mean().sort_index()
                axes[i].plot(grouped.index * 100, grouped.values, 
                             marker=style['marker'], color=style['color'], 
                             linewidth=2, label=style['label'])
        
        axes[i].set_xlabel('RL Penetration Rate (%)', fontsize=12)
        axes[i].set_ylabel(ylabel, fontsize=12)
        axes[i].set_title(ylabel, fontsize=14, fontweight='bold')
        axes[i].legend()
        axes[i].grid(True, linestyle='--', alpha=0.7)
        
    # 隐藏第 6 个多余的子图
    axes[5].axis('off')
        
    plt.suptitle('PPO vs SAC Performance Comparison (5 Key Metrics)', fontsize=20, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(output_image, dpi=300)
    print(f"对比图表已保存至: {output_image}")

if __name__ == "__main__":
    ppo_path = "f:/123/comprehensive_eval_results.csv"
    sac_path = "f:/123/sac_comprehensive_eval_results.csv"
    output_path = "f:/123/ppo_vs_sac_comparison_5plots.png"
    plot_combined_performance(ppo_path, sac_path, output_path)

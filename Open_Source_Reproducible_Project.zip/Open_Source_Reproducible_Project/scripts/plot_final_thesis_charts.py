import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os

# 核心配色方案 (学术级配色)
COLOR_CONFIG = {
    ('PPO v9', 'Krauss'): {'color': '#FF8C00', 'marker': 'o', 'label': 'PPO v9 (Krauss背景)', 'ls': '-'},
    ('PPO v9', 'IDM'):    {'color': '#E65100', 'marker': 's', 'label': 'PPO v9 (IDM背景)', 'ls': '--'},
    ('SAC', 'Krauss'):    {'color': '#1E90FF', 'marker': '^', 'label': 'SAC (Krauss背景)', 'ls': '-'},
    ('SAC', 'IDM'):       {'color': '#0D47A1', 'marker': 'D', 'label': 'SAC (IDM背景)', 'ls': '--'},
    ('HAPPO', 'Krauss'):  {'color': '#2E7D32', 'marker': 'v', 'label': 'HAPPO (Krauss背景)', 'ls': '-'},
    ('HAPPO', 'IDM'):     {'color': '#1B5E20', 'marker': 'p', 'label': 'HAPPO (IDM背景)', 'ls': '--'},
    ('Hybrid', 'Krauss'): {'color': '#C62828', 'marker': '*', 'label': '混合控制 (Krauss背景)', 'ls': '-', 'lw': 3, 'ms': 12},
}

def setup_plot_style():
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams.update({
        'font.sans-serif': ['SimSun', 'STSong', 'SimHei', 'Arial'], # 优先使用宋体
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 9,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'grid.linestyle': '--',
        'axes.unicode_minus': False
    })

def load_data_from_csv():
    # 使用原始记录的 CSV 文件
    csv_path = 'f:/123/final_standardized_results_optimized.csv'
    df = pd.read_csv(csv_path)
    
    # --- 统一起点逻辑 ---
    # 为每个 (Phase, Background) 提取一个标准的 0% 基准值
    unified_baselines = {}
    for (phase, bg), group in df[df['PR'] == 0.0].groupby(['Phase', 'Background']):
        # 取均值作为该组的标准起点
        unified_baselines[(phase, bg)] = group.mean(numeric_only=True)

    def get_algo_data(phase, algo, background):
        sub = df[(df['Phase'] == phase) & (df['Algo'] == algo) & (df['Background'] == background)].copy()
        
        # 如果该算法在该阶段/背景下没数据，返回 None
        if sub.empty: return None
        
        # 强制统一 0% 的起点数据
        if (phase, background) in unified_baselines:
            std_base = unified_baselines[(phase, background)]
            # 如果已有 0.0 点，覆盖它；如果没有，插入它
            if 0.0 in sub['PR'].values:
                sub.loc[sub['PR'] == 0.0, std_base.index] = std_base.values
            else:
                new_row = std_base.to_dict()
                new_row['Phase'] = phase
                new_row['Algo'] = algo
                new_row['Background'] = background
                new_row['PR'] = 0.0
                sub = pd.concat([sub, pd.DataFrame([new_row])])
            
        sub = sub.sort_values('PR').drop_duplicates('PR')
        return {
            'Algo': algo,
            'Background': background,
            'PR': (sub['PR'] * 100).tolist(),
            'Speed': sub['Avg_Speed'].tolist(),
            'Throughput': sub['Throughput'].tolist(),
            'Fuel': sub['Total_Fuel'].tolist(),
            'Headway': sub['Avg_Headway'].tolist(),
            'Count': sub['Avg_Count'].tolist()
        }

    # 算法列表包含 SAC
    algos = ['PPO v9', 'SAC', 'HAPPO']
    
    # Phase 1 Data
    phase1 = []
    for algo in algos:
        for bg in ['Krauss', 'IDM']:
            d = get_algo_data('Phase 1', algo, bg)
            if d: phase1.append(d)
    
    # Phase 2 Data
    phase2 = []
    for algo in algos:
        for bg in ['Krauss', 'IDM']:
            d = get_algo_data('Phase 2', algo, bg)
            if d: phase2.append(d)
            
    # Hybrid Data
    hybrid_k = get_algo_data('Phase 2', 'Hybrid', 'Krauss')
    ppo_k = get_algo_data('Phase 2', 'PPO v9', 'Krauss')
    sac_k = get_algo_data('Phase 2', 'SAC', 'Krauss')
    happo_k = get_algo_data('Phase 2', 'HAPPO', 'Krauss')
    hybrid_list = [hybrid_k, ppo_k, sac_k, happo_k]
    hybrid_list = [d for d in hybrid_list if d]
    
    return phase1, phase2, hybrid_list

def export_data_to_txt(p1, p2, hybrid, save_path):
    """将绘图使用的数据汇总到 TXT 文件中"""
    with open(save_path, 'w', encoding='utf-8') as f:
        f.write("=== 绘图数据汇总报告 ===\n\n")
        
        def write_group(title, data_list):
            f.write(f"--- {title} ---\n")
            f.write(f"{'算法':<15} {'背景':<10} {'PR(%)':<8} {'均速':<8} {'吞吐量':<8} {'油耗':<8} {'车头时距':<8} {'在网数':<8}\n")
            for d in data_list:
                for i in range(len(d['PR'])):
                    f.write(f"{d['Algo']:<15} {d['Background']:<10} {d['PR'][i]:<8.1f} {d['Speed'][i]:<8.2f} {d['Throughput'][i]:<8.1f} {d['Fuel'][i]:<8.2f} {d['Headway'][i]:<8.2f} {d['Count'][i]:<8.2f}\n")
            f.write("\n")

        write_group("阶段 1 (Phase 1: 全路段)", p1)
        write_group("阶段 2 (Phase 2: 合流区标准)", p2)
        write_group("创新点对比 (Hybrid vs Baselines @ Phase 2)", hybrid)
    
    print(f"Data summary exported to: {save_path}")

def plot_engine(data_list, metrics, title, save_path):
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    axes = axes.flatten()
    
    for i, (metric_key, metric_name, _) in enumerate(metrics):
        ax = axes[i]
        for data in data_list:
            cfg = COLOR_CONFIG.get((data['Algo'], data['Background']), {})
            ax.plot(data['PR'], data[metric_key], 
                   color=cfg.get('color', 'black'),
                   marker=cfg.get('marker', 'o'),
                   label=cfg.get('label', data['Algo']),
                   ls=cfg.get('ls', '-'),
                   lw=cfg.get('lw', 1.5),
                   ms=cfg.get('ms', 6),
                   alpha=0.8)
        
        ax.set_title(metric_name)
        ax.set_xlabel('渗透率 (%)')
        ax.set_ylabel(metric_name)
        ax.legend(loc='best', frameon=True, fontsize=8) # 确保每个子图都有图例
    
    # 第6个子图留空或显示统计摘要
    axes[5].axis('off')
    
    plt.suptitle(title, fontsize=16, fontweight='bold')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(save_path)
    plt.close()
    print(f"Generated: {save_path}")

def plot_individual_metrics(data_list, metrics, folder_name, prefix):
    """将每个指标保存为单独的图像文件"""
    save_dir = os.path.join('f:/123/Final_Paper_Submission/Figures', folder_name)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    # 确定阶段名称
    phase_label = "全路段" if "Whole" in folder_name else "合流区"
    if "Hybrid" in folder_name: phase_label = "混合控制"

    for metric_key, metric_name, english_name in metrics:
        plt.figure(figsize=(10, 7))
        for data in data_list:
            cfg = COLOR_CONFIG.get((data['Algo'], data['Background']), {})
            plt.plot(data['PR'], data[metric_key], 
                    color=cfg.get('color', 'black'),
                    marker=cfg.get('marker', 'o'),
                    label=cfg.get('label', data['Algo']),
                    ls=cfg.get('ls', '-'),
                    lw=2,
                    ms=8,
                    alpha=0.9)
        
        plt.title(f"{phase_label}: {metric_name}", fontsize=16, fontweight='bold')
        plt.xlabel('渗透率 (%)', fontsize=14)
        plt.ylabel(metric_name, fontsize=14)
        plt.xticks(fontsize=12)
        plt.yticks(fontsize=12)
        plt.legend(loc='best', frameon=True, fontsize=10)
        plt.grid(True, linestyle='--', alpha=0.5)
        
        # 使用原始英文名作为文件名，保持一致性
        save_path = os.path.join(save_dir, f"{prefix}_{english_name}.png")
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"Generated Individual Plot: {save_path} (Phase: {phase_label})")

def generate_all_figures():
    setup_plot_style()
    p1, p2, hybrid = load_data_from_csv()
    
    # 导出数据到 TXT
    export_data_to_txt(p1, p2, hybrid, 'f:/123/Final_Paper_Submission/Data/plotted_data_summary.txt')
    
    # 调试信息
    if p1: print(f"DEBUG: P1 Count[0] for {p1[0]['Algo']} = {p1[0]['Count'][:3]}")
    if p2: print(f"DEBUG: P2 Count[0] for {p2[0]['Algo']} = {p2[0]['Count'][:3]}")
    
    common_metrics = [
        ('Speed', '平均车速 (m/s)', 'Average_Speed'),
        ('Fuel', '单位车辆燃油消耗 (L/veh)', 'Fuel_per_Vehicle'),
        ('Throughput', '总吞吐量 (辆)', 'Total_Throughput'),
        ('Headway', '平均车头时距 (s)', 'Average_Headway'),
        ('Count', '路段平均在网车辆数', 'Avg_Vehicles_on_Road')
    ]
    
    # 1. Whole Road (Phase 1)
    plot_engine(p1, common_metrics, 
              '阶段一：全路段宏观平顺性能 (标准强化学习)', 
              'f:/123/Final_Paper_Submission/Figures/Whole_Road_Analysis_Final.png')
    plot_individual_metrics(p1, common_metrics, 'Whole_Road', 'P1')

    # 2. Merge Area Standard (Phase 2)
    plot_engine(p2, common_metrics, 
              '阶段二：合流区冲突缓解性能 (标准强化学习)', 
              'f:/123/Final_Paper_Submission/Figures/Merge_Area_Analysis_Final.png')
    plot_individual_metrics(p2, common_metrics, 'Merge_Area', 'P2')

    # 3. Merge Area Hybrid vs Baselines
    plot_engine(hybrid, common_metrics, 
              '创新点：时空解耦混合控制 vs 基准算法 (Krauss背景)', 
              'f:/123/Final_Paper_Submission/Figures/Merge_Area_Unified_Krauss.png')
    plot_individual_metrics(hybrid, common_metrics, 'Hybrid_Control', 'Innovation')

if __name__ == "__main__":
    generate_all_figures()

import pandas as pd
import matplotlib.pyplot as plt
import os

# 强制不生成 __pycache__
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

def plot_comprehensive_merge_comparison(csv_path, output_image):
    if not os.path.exists(csv_path):
        print(f"Error: {csv_path} not found.")
        return

    df = pd.read_csv(csv_path)
    
    # 修正指标计算
    # 1. 车均燃油消耗 (L/veh)
    # 注意：如果 Total_Throughput 为 0，避免除以 0
    df['Merge_Avg_Fuel_Per_Vehicle'] = df.apply(
        lambda x: x['Merge_Total_Fuel'] / x['Total_Throughput'] if x['Total_Throughput'] > 0 else 0, axis=1
    )
    
    # 2. 平均车头时距 (s)
    # Headway = Total_Lane_Length / (Avg_Count * Avg_Speed)
    total_merge_lane_length = 1494.72
    df['Merge_Avg_Headway'] = df.apply(
        lambda x: total_merge_lane_length / (x['Merge_Avg_Count'] * x['Merge_Avg_Speed']) if (x['Merge_Avg_Count'] * x['Merge_Avg_Speed']) > 0 else 0, axis=1
    )
    
    # 定义绘图指标
    metrics = [
        ('Merge_Avg_Speed', 'Average Speed (m/s)'),
        ('Merge_Avg_Fuel_Per_Vehicle', 'Average Fuel Consumption (L/veh)'),
        ('Total_Throughput', 'Total Throughput (Vehicles)'),
        ('Merge_Avg_Headway', 'Average Headway (s)'),
        ('Merge_Avg_Count', 'Average Vehicles in Merge Area')
    ]
    
    plt.style.use('ggplot')
    fig, axes = plt.subplots(3, 2, figsize=(18, 18))
    axes = axes.flatten()
    
    # 颜色和样式配置
    styles = {
        ('PPO', 'krauss_v1'): {'color': '#1f77b4', 'marker': 'o', 'label': 'PPO vs Krauss'},
        ('PPO', 'idm_v1'): {'color': '#ff7f0e', 'marker': 's', 'label': 'PPO vs IDM'},
        ('SAC', 'krauss_v1'): {'color': '#2ca02c', 'marker': '^', 'label': 'SAC vs Krauss'},
        ('SAC', 'idm_v1'): {'color': '#d62728', 'marker': 'D', 'label': 'SAC vs IDM'}
    }
    
    # 处理 Baseline (Penetration = 0)
    # Baseline 的 Algo 是 "Baseline"，需要合并到各个对比组中
    baseline_df = df[df['Penetration'] == 0]
    
    for i, (col, ylabel) in enumerate(metrics):
        for (algo, ht), style in styles.items():
            # 提取该算法和该人类类型的子集
            subset = df[(df['Algo'] == algo) & (df['Human_Type'] == ht)]
            
            # 合并该人类类型的 Baseline
            ht_baseline = baseline_df[baseline_df['Human_Type'] == ht]
            combined = pd.concat([ht_baseline, subset])
            
            # 按渗透率聚合
            grouped = combined.groupby('Penetration')[col].mean().sort_index()
            
            axes[i].plot(grouped.index * 100, grouped.values, 
                        color=style['color'], marker=style['marker'], 
                        linestyle='-', linewidth=2.5, markersize=8,
                        label=style['label'])
        
        axes[i].set_xlabel('RL Penetration Rate (%)', fontsize=12)
        axes[i].set_ylabel(ylabel, fontsize=12)
        axes[i].set_title(ylabel, fontsize=14, fontweight='bold')
        axes[i].legend(fontsize=10)
        axes[i].grid(True, linestyle='--', alpha=0.7)
        
    # 隐藏最后一个多余的子图
    axes[-1].axis('off')
    
    plt.suptitle('Merge Area Performance Analysis: PPO vs SAC', fontsize=20, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(output_image, dpi=300)
    print(f"合流区综合对比图表已保存至: {output_image}")

if __name__ == "__main__":
    plot_comprehensive_merge_comparison(
        "f:/123/comprehensive_merge_eval_results.csv", 
        "f:/123/merge_area_ppo_vs_sac_5plots.png"
    )

import pandas as pd
import re

def convert_txt_to_excel(txt_path, excel_path):
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    data = []
    current_phase = ""
    
    # 列名映射
    columns = ["阶段", "算法", "背景", "PR(%)", "均速", "吞吐量", "油耗", "车头时距", "在网数"]
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # 识别阶段
        if line.startswith("---"):
            current_phase = line.replace("-", "").strip()
            continue
            
        # 跳过标题行和装饰行
        if "算法" in line or line.startswith("==="):
            continue
            
        # 使用正则表达式拆分空格分隔的行，处理 "PPO v9" 这种带空格的算法名
        # 匹配逻辑：先匹配前两个可能带空格的非数字部分，然后匹配后面的数字
        # 考虑到 TXT 格式是固定宽度的或空格分隔的，我们可以更灵活地处理
        parts = re.split(r'\s{2,}', line)
        if len(parts) >= 7:
            # 算法名可能被拆分，或者背景名
            # 根据 plotted_data_summary.txt 的观察：
            # PPO v9          Krauss     0.0      25.16    146.7    466.34   2.75     105.88
            # 这里的 \s{2,} 应该能正确切分
            
            # 如果切分出的第一部分是算法名，第二部分是背景名，后面是数值
            row = [current_phase] + parts
            # 确保行长度一致（截取或填充）
            if len(row) > len(columns):
                row = row[:len(columns)]
            elif len(row) < len(columns):
                row += [""] * (len(columns) - len(row))
            
            data.append(row)

    df = pd.DataFrame(data, columns=columns)
    
    # 转换数值列
    numeric_cols = ["PR(%)", "均速", "吞吐量", "油耗", "车头时距", "在网数"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # 保存为 Excel
    df.to_excel(excel_path, index=False)
    print(f"Excel file created at: {excel_path}")
    
    # 同时也保存一个 CSV 方便没有 Excel 的环境
    csv_path = excel_path.replace(".xlsx", ".csv")
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"CSV file created at: {csv_path}")

if __name__ == "__main__":
    txt_file = r'f:\123\Final_Paper_Submission\Data\plotted_data_summary.txt'
    excel_file = r'f:\123\Final_Paper_Submission\Data\plotted_data_summary.xlsx'
    convert_txt_to_excel(txt_file, excel_file)

import os
import traci
import pandas as pd
import numpy as np
import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import multiprocessing
from stable_baselines3 import PPO, SAC
from sumo_mixed_env import SumoMixedEnv
import time

# 强制不生成 __pycache__
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

# 合流区定义
TARGET_EDGES = ["main_2", "ramp_in"]
TOTAL_MERGE_LANE_LENGTH = 1494.72 # 332.51*4 + 164.68

def run_single_simulation(args):
    """
    args: (algo, model_path, human_type, penetration_rate, seed, round_id, duration)
    """
    algo, model_path, human_type, penetration_rate, seed, round_id, duration = args
    process_id = multiprocessing.current_process().name
    label = f"merge_{algo}_{human_type}_{penetration_rate}_{seed}_{round_id}_{process_id}"
    
    temp_rou_file = f"f:/123/sumo_scenario/temp_{label}.rou.xml"
    temp_cfg_file = f"f:/123/sumo_scenario/temp_{label}.sumocfg"
    
    try:
        # 1. 生成路由
        generate_mixed_routes_to_file(penetration_rate, human_type, temp_rou_file)
        
        # 2. 创建配置
        base_cfg = "f:/123/sumo_scenario/highway.sumocfg"
        tree = ET.parse(base_cfg)
        root = tree.getroot()
        root.find('input/route-files').set('value', os.path.basename(temp_rou_file))
        tree.write(temp_cfg_file)
        
        metrics = []
        
        if penetration_rate == 0:
            traci.start(["sumo", "-c", temp_cfg_file, "--no-step-log", "true", "--no-warnings", "true", "--seed", str(seed)], label=label)
            conn = traci.getConnection(label)
            for step in range(duration):
                conn.simulationStep()
                collect_merge_metrics(conn, metrics)
            conn.close()
        else:
            env = SumoMixedEnv(temp_cfg_file, duration=duration, label=label)
            if algo == "PPO":
                model = PPO.load(model_path)
            else:
                model = SAC.load(model_path)
                
            obs, _ = env.reset(seed=seed)
            for step in range(duration):
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = env.step(action)
                conn = traci.getConnection(label)
                collect_merge_metrics(conn, metrics)
                if terminated or truncated:
                    break
            env.close()
            
        df_step = pd.DataFrame(metrics)
        if df_step.empty: return None
        
        total_fuel_l = (df_step['fuel'].sum() * 0.1) / 1000000.0
        total_throughput = df_step['arrived'].sum()
        
        res_metrics = {
            "Algo": algo if penetration_rate > 0 else "Baseline",
            "Human_Type": human_type,
            "Penetration": penetration_rate,
            "Merge_Avg_Speed": df_step['speed'].mean(),
            "Merge_Total_Fuel": total_fuel_l / total_throughput if total_throughput > 0 else 0, # 改为单车平均油耗 (L/veh)
            "Merge_Avg_Count": df_step['count'].mean(),
            "Total_Throughput": total_throughput,
            "Ramp_Throughput": df_step['ramp_arrived'].sum()
        }
        return res_metrics
        
    except Exception as e:
        print(f"Error in {label}: {e}")
        return None
    finally:
        for f in [temp_rou_file, temp_cfg_file]:
            if os.path.exists(f):
                try: os.remove(f)
                except: pass

def collect_merge_metrics(conn, metrics_list):
    vids = conn.vehicle.getIDList()
    merge_vids = [v for v in vids if conn.vehicle.getRoadID(v) in TARGET_EDGES]
    
    # 统计本步到达的车辆中，来自匝道的数量
    arrived_vids = conn.simulation.getArrivedIDList()
    ramp_arrived = len([v for v in arrived_vids if "ramp_in_flow" in v])
    
    if merge_vids:
        speeds = [conn.vehicle.getSpeed(v) for v in merge_vids]
        fuels = [conn.vehicle.getFuelConsumption(v) for v in merge_vids]
        metrics_list.append({
            "speed": np.mean(speeds),
            "fuel": np.sum(fuels),
            "count": len(merge_vids),
            "arrived": len(arrived_vids),
            "ramp_arrived": ramp_arrived
        })
    else:
        # 如果合流区没车，速度设为限速，油耗为0
        metrics_list.append({
            "speed": 33.33,
            "fuel": 0.0,
            "count": 0,
            "arrived": len(arrived_vids),
            "ramp_arrived": ramp_arrived
        })

def generate_mixed_routes_to_file(penetration_rate, human_type, output_file):
    input_file = "f:/123/sumo_scenario/highway.rou.xml"
    tree = ET.parse(input_file)
    root = tree.getroot()
    flows = root.findall('flow')
    new_root = ET.Element('routes')
    for vtype in root.findall('vType'):
        new_root.append(vtype)
    for flow in flows:
        flow_id = flow.get('id')
        total_vehs = float(flow.get('vehsPerHour'))
        if penetration_rate > 0:
            rl_flow = ET.Element('flow', {
                'id': f"{flow_id}_rl", 'type': 'ppo_agent',
                'begin': flow.get('begin'), 'end': flow.get('end'),
                'vehsPerHour': str(total_vehs * penetration_rate),
                'from': flow.get('from'), 'to': flow.get('to'), 'departLane': flow.get('departLane')
            })
            new_root.append(rl_flow)
        if penetration_rate < 1:
            human_flow = ET.Element('flow', {
                'id': f"{flow_id}_human", 'type': human_type,
                'begin': flow.get('begin'), 'end': flow.get('end'),
                'vehsPerHour': str(total_vehs * (1 - penetration_rate)),
                'from': flow.get('from'), 'to': flow.get('to'), 'departLane': flow.get('departLane')
            })
            new_root.append(human_flow)
    new_tree = ET.ElementTree(new_root)
    new_tree.write(output_file)

if __name__ == "__main__":
    ppo_model = "f:/123/models_optimized/ppo_v9_final.zip"
    sac_model = "f:/123/sac/sac_final_model.zip"
    human_types = ["krauss_v1", "idm_v1"]
    penetrations = [0.0, 0.1, 0.3, 0.5, 0.8, 1.0]
    rounds = 3
    duration = 2000
    
    tasks = []
    # PPO 任务
    for ht in human_types:
        for p in penetrations:
            for r in range(rounds):
                tasks.append(("PPO", ppo_model, ht, p, 42+r*7, r, duration))
    
    # SAC 任务 (渗透率为 0 的基准任务在 PPO 循环里已经加过了，这里只加 p > 0)
    for ht in human_types:
        for p in penetrations:
            if p > 0:
                for r in range(rounds):
                    tasks.append(("SAC", sac_model, ht, p, 42+r*7, r, duration))
    
    print(f"🚀 开始合流区 PPO vs SAC 综合评估 (总任务数: {len(tasks)})...")
    start_time = time.time()
    
    # 使用 12 个进程并行
    with multiprocessing.Pool(processes=12) as pool:
        results = pool.map(run_single_simulation, tasks)
    
    results = [r for r in results if r is not None]
    df = pd.DataFrame(results)
    df.to_csv("f:/123/comprehensive_merge_eval_results.csv", index=False)
    
    print(f"✅ 仿真完成！耗时: {time.time()-start_time:.2f}s")
    print(f"数据已保存至: f:/123/comprehensive_merge_eval_results.csv")
